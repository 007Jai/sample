import React from 'react';
import Weather from './components/Weather';
// import Clock from './components/Clock';


const App = () => {
    
    return (
        <>
           {/* <Clock/> */}
           <Weather/>
        </>
    )
}
export default App;




