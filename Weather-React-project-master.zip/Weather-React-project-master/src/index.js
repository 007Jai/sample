import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
// import name from './App'
import './index.css'
const root = ReactDOM.createRoot(document.getElementById('root'));

// ./ ../
// Components ---> function (return ) Capital letter

// var ❌ const ✅ let ✅
// setInterval(()=>{

  root.render(
  <React.Fragment>
  {/* <h1>{name}</h1> */}
          <App/>
  </React.Fragment>
  // JSX javascript and xml
);

// }, 1000)



// ✅Html and Js mixed 


// JSX---> Java-Script and XML
// Rules or Syntax
/*
XML inside javascript {}
class | className

style: objects
backgroudColor: 'cyan' 

*/